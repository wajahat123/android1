# TypedToDo
TypedTodo Is a typescript Todo list web app Made with HTML, Sass And Typescript.
See Live : https://typedtodo-cbf7b.firebaseapp.com/
